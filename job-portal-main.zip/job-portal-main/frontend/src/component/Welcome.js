import React, { useState } from "react";
import {
  Grid,
  Typography,
  Button,
  TextField,
  Card,
  CardContent,
  CardActions,
  Avatar,
} from "@material-ui/core";
import { ArrowForward, ErrorOutline, Home } from "@material-ui/icons";


const jobListings = [
  {
    company: "Google",
    title: "Software Engineer",
    location: "Mountain View, CA",
    logo: "https://logo.clearbit.com/google.com",
  },
  {
    company: "Amazon",
    title: "Data Scientist",
    location: "Seattle, WA",
    logo: "https://logo.clearbit.com/amazon.com",
  },
  {
    company: "Microsoft",
    title: "Cloud Engineer",
    location: "Redmond, WA",
    logo: "https://logo.clearbit.com/microsoft.com",
  },
  {
    company: "Apple",
    title: "UI/UX Designer",
    location: "Cupertino, CA",
    logo: "https://logo.clearbit.com/apple.com",
  },
  {
    company: "Meta",
    title: "Product Manager",
    location: "Menlo Park, CA",
    logo: "https://logo.clearbit.com/meta.com",
  },
  {
    company: "Netflix",
    title: "Backend Developer",
    location: "Los Gatos, CA",
    logo: "https://logo.clearbit.com/netflix.com",
  },
  {
    company: "Tesla",
    title: "AI Researcher",
    location: "Palo Alto, CA",
    logo: "https://logo.clearbit.com/tesla.com",
  },
];

const Welcome = () => {
  const [stoppedCards, setStoppedCards] = useState({}); // Tracks which cards are stopped

  const toggleCardMovement = (index) => {
    setStoppedCards((prevState) => ({
      ...prevState,
      [index]: !prevState[index], // Toggle the animation state
    }));
  };

  return (
    <Grid
      container
      direction="column"
      alignItems="center"
      style={{
        padding: "30px",
        minHeight: "93vh",
        backgroundColor: "#f5f5f5",
      }}
    >
      {/* Welcome Header */}
      <Grid item>
        <Typography variant="h2" color="primary" gutterBottom>
          Welcome to Connect - HireHub
        </Typography>
      </Grid>
      <Grid item>
        <Typography variant="h6" color="textSecondary" gutterBottom>
          Find your dream job or hire the best talents.
        </Typography>
      </Grid>
      {/* Job Search */}
      <Grid item>
        <TextField
          label="Search for Jobs"
          variant="outlined"
          size="medium"
          fullWidth
          style={{ maxWidth: "400px", margin: "20px 0" }}
        />
      </Grid>
      <Grid item>
        <Button
          variant="contained"
          color="primary"
          endIcon={<ArrowForward />}
          size="large"
        href="/home">
          Get Started
        </Button>
      </Grid>
      {/* Job Listings Section */}
      <Grid item style={{ marginTop: "40px", width: "100%" }}>
      
        <Grid container spacing={3} justifyContent="center">
          {jobListings.map((job, index) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={index}>
              <Card
                className={`job-card ${
                  stoppedCards[index] ? "stopped" : "moving"
                }`}
                onClick={() => toggleCardMovement(index)}
              >
                <CardContent>
                  <Grid container alignItems="center" spacing={2}>
                    <Grid item>
                      <Avatar
                        src={job.logo}
                        alt={job.company}
                        style={{ width: 60, height: 60 }}
                      />
                    </Grid>
                    <Grid item>
                      <Typography variant="h6" gutterBottom>
                        {job.company}
                      </Typography>
                      <Typography variant="subtitle1" color="textSecondary">
                        {job.title}
                      </Typography>
                      <Typography variant="subtitle2" color="textSecondary">
                        {job.location}
                      </Typography>
                    </Grid>
                  </Grid>
                </CardContent>
                <CardActions>
                  <Button
                    size="small"
                    color="primary"
                    variant="contained"
                    fullWidth
                  >
                    Apply Now
                  </Button>
                </CardActions>
              </Card>
            </Grid>
          ))}
        </Grid>
      </Grid>
    </Grid>
  );
};

export const ErrorPage = () => {
  return (
    <Grid
      container
      direction="column"
      alignItems="center"
      justifyContent="center"
      style={{
        padding: "30px",
        minHeight: "93vh",
        backgroundColor: "#fce4ec",
      }}
    >
      <Grid item>
        <ErrorOutline
          style={{ fontSize: 100, color: "#d32f2f", marginBottom: "20px" }}
        />
      </Grid>
      <Grid item>
        <Typography variant="h2" color="error" gutterBottom>
          Error 404
        </Typography>
      </Grid>
      <Grid item>
        <Typography variant="h6" color="textSecondary" gutterBottom>
          The page you are looking for does not exist.
        </Typography>
      </Grid>
      <Grid item>
        <Button
          variant="contained"
          color="primary"
          startIcon={<Home />}
          href="/"
        >
          Go Home
        </Button>
      </Grid>
    </Grid>
  );
};

export default Welcome;
